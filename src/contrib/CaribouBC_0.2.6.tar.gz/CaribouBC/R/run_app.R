run_app <-
function(app="CaribouBC") {
  shiny::runApp(
    system.file(paste0("shiny/", match.arg(app)), package="CaribouBC"),
    display.mode = "normal")
}
